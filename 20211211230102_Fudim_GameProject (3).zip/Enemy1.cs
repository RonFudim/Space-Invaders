﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceInvadersGame
{
    class Enemy1
    {
        // ====== Attributes ====== //

        public string[] appearance = new string[3] {"\\(|-|)/",
                                                          "<=-0-=>",
                                                          "   V"};
        public string[] shipErase = new string[3];
        public int health = 10;
        public int speed = 1;

        public Enemy1()
        {

        }
    }
}
