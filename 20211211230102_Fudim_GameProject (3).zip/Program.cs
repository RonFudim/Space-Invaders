﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceInvadersGame
{
    class Program
    {
        // ====== Keyboard Input ====== //

        static ConsoleKey myKey = ConsoleKey.NoName;

        // ====== Coordinates ====== //

        static int shipOldX;
        static int shipOldY;
        static int shipCurrentX = 40;
        static int shipCurrentY = 25;
        static int bulletLocationX = shipCurrentX;
        static int bulletLocationY = shipCurrentY - 1;
        static int atmosphereCoordinates = 22;

        // ====== Enemy 1 ====== //

        static int enemy1Top;
        static int enemy1OldLocationX;
        static int enemy1OldLocationY;
        static int[] enemy1PositionX = new int[1000];
        static int[] enemy1PositionY = new int[1000];
        static int oldEnemyXPosition;

        // ====== Bullet Array ====== //

        static int[] bulletArrayX = new int[100];
        static int[] bulletArrayY = new int[100];
        static int bulletNum = 100;

        // ====== Quantities ====== //

        static int i;
        static int threadSpeed = 35;
        static int score = 0;
        static int aliens = 50;
        static int enemiesInAtmosphere = 0;
        static int energy;

        // ====== Counters ====== //

        static int fc = 0;
        static int bulletCounter = 0;
        static int enemy1Counter = 0;

        // ====== Booleans ====== //

        static bool gameOver = false;
        static bool[] enemy1Movement = new bool[1000];

        // ====== Screen Size ====== //

        static int windowWidth = 100;
        static int windowHeight = 40;

        // ====== Title Screen Strings ====== //

        static string enterScreen = "Press Enter to Start...";
        static string generalSpeech = "General Grievous: The battle against the aliens is about to begin soldier " +
            "\n\nGeneral Grievous: Upon this battle depends the survival of human civilization \n\nGeneral Grievous: If we can stand up to them," +
            " we will finally be free \n\nGeneral Grievous: The life of the world will be able to move forward\n\nGeneral Grievous: But if we fail, " +
            "the whole world will sink into the abyss of a new dark age";
        static string generalQuestions = "General Grievous: REPORT!, what is your name grunt: ";
        static string soldierName = "\nGeneral Grievous: Nice to have you on board Fly Lieutenant";
        static string soldierLocation = "\n\nGeneral Grievous: Where you from Meat Bag: ";
        static string soldierNameResponse;
        static string soldierLocationResponse;

        static void Main(string[] args)
        {
            /*===================================================
                             OPERATION INVASION
             ===================================================*/
            
            Console.CursorVisible = true;
            // ====== Window Screen Boundaries ====== //
            Console.ForegroundColor = ConsoleColor.White;
            Console.SetWindowSize(windowWidth, windowHeight);
            Console.SetCursorPosition(35, 20);
            Console.Write(enterScreen);
            Console.ReadKey();
            Console.Clear();

            // ====== Intro Conversation ====== //
            
            Console.SetCursorPosition(0, 0);
            IntroConversation(ref generalSpeech);
            Console.ReadKey();
            Console.Clear();

            IntroConversation(ref generalQuestions);
            Console.Write("\n\nEnter your name: ");

            soldierNameResponse = Console.ReadLine();

            IntroConversation(ref soldierName);

            IntroConversation(ref soldierLocation);
            Console.Write("\n\nEnter where you are from: ");

            soldierLocationResponse = Console.ReadLine();
            
            Console.Clear();
            
            Console.CursorVisible = false;
            // ====== Title ====== //

            while (true)
            {
                TitleScreen();
                System.Threading.Thread.Sleep(500);
                if (Console.KeyAvailable)
                {
                    myKey = Console.ReadKey(true).Key;
                    if (myKey == ConsoleKey.Enter)
                    {
                        Console.Clear();
                        break;
                    }
                }
            }
            Console.ForegroundColor = ConsoleColor.Green;
            for(i = 0; i < 3; i++)
            {
                Console.SetCursorPosition(20, 15);
                string[] titleNum = new string[3] {
                    @"                
                                            ░░███╗░░
                                            ░████║░░
                                            ██╔██║░░
                                            ╚═╝██║░░
                                            ███████╗
                                            ╚══════╝",
                                                        @"                
                                            ██████╗░
                                            ╚════██╗
                                            ░░███╔═╝
                                            ██╔══╝░░
                                            ███████╗
                                            ╚══════╝",
                                                        @"               
                                            ██████╗░
                                            ╚════██╗
                                            ░█████╔╝
                                            ░╚═══██╗
                                            ██████╔╝
                                            ╚═════╝░",
                                                        };
                
                Console.Write(titleNum[i]);
                System.Threading.Thread.Sleep(1250);
                Console.Clear();
             
            }

            /*===================================================
                                  OBJECTS
             ===================================================*/

            /*====================
               SPEED FALCON SHIP 
             ====================*/

            SpeedFalconShip speedFalcon = new SpeedFalconShip(ref soldierNameResponse, ref soldierLocationResponse, ref energy);

            /*====================
                    ENEMY 1 
             ====================*/

            Enemy1 enemy1 = new Enemy1();

            /*===================================================
                              MAIN GAME EVENT
             ===================================================*/

            while (!gameOver)
            {
                if (Console.KeyAvailable)
                {
                    myKey = Console.ReadKey(true).Key;
                }
                CharacterHeadsUpDisplay(speedFalcon.soldierName, speedFalcon.soldierLocation, speedFalcon.health);
                ConsoleKey dMyKey = Move(speedFalcon.speed);
                Limits();
                Draw(speedFalcon.shipAppearance, speedFalcon.shipErase, dMyKey);
                Console.ForegroundColor = ConsoleColor.DarkRed;
                BulletSpawn();
                if (fc % 4 == 0)
                {
                    BulletMove();
                }
                if (fc % 150 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Enemy1Spawn();
                    Enemy1Draw(enemy1.appearance, enemy1PositionX, enemy1PositionY);
                }
                Collision(enemy1.appearance);
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                fc++;
                myKey = ConsoleKey.NoName;
            }
        }

        /*===================================================
                     INTRO CONVERSATION FUNCTION
         ===================================================*/
        static void IntroConversation(ref string gameText)
        {
            for (i = 0; i < gameText.Length; i++)
            {
                System.Threading.Thread.Sleep(threadSpeed);
                Console.Write(gameText[i]);
            }
        }

        /*===================================================
                        TITLE SCREEN FUNCTION
         ===================================================*/
        static void TitleScreen()
        {
            Console.SetCursorPosition(5, 5);

            // ====== Array for title color switch ======= //

            ConsoleColor[] colorForTitle = { ConsoleColor.DarkRed, ConsoleColor.Cyan, ConsoleColor.Green };

            // ====== Random number for array ====== //

            Random rnd = new Random();
            int rndColor = rnd.Next(0, 3);
            string title =
   @"            ░█████╗░██████╗░███████╗██████╗░░█████╗░████████╗██╗░█████╗░███╗░░██╗
                 ██╔══██╗██╔══██╗██╔════╝██╔══██╗██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║
                 ██║░░██║██████╔╝█████╗░░██████╔╝███████║░░░██║░░░██║██║░░██║██╔██╗██║
                 ██║░░██║██╔═══╝░██╔══╝░░██╔══██╗██╔══██║░░░██║░░░██║██║░░██║██║╚████║
                 ╚█████╔╝██║░░░░░███████╗██║░░██║██║░░██║░░░██║░░░██║╚█████╔╝██║░╚███║
                 ░╚════╝░╚═╝░░░░░╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝

                       ██╗███╗░░██╗██╗░░░██╗░█████╗░░██████╗██╗░█████╗░███╗░░██╗
                       ██║████╗░██║██║░░░██║██╔══██╗██╔════╝██║██╔══██╗████╗░██║
                       ██║██╔██╗██║╚██╗░██╔╝███████║╚█████╗░██║██║░░██║██╔██╗██║
                       ██║██║╚████║░╚████╔╝░██╔══██║░╚═══██╗██║██║░░██║██║╚████║
                       ██║██║░╚███║░░╚██╔╝░░██║░░██║██████╔╝██║╚█████╔╝██║░╚███║
                       ╚═╝╚═╝░░╚══╝░░░╚═╝░░░╚═╝░░╚═╝╚═════╝░╚═╝░╚════╝░╚═╝░░╚══╝";

            Console.ForegroundColor = colorForTitle[rndColor];
            Console.Write(title);

            Console.ForegroundColor = ConsoleColor.DarkRed;

            Console.SetCursorPosition(5, 20);
            Console.WriteLine("\n                                Move your ship using the arrow keys");
            Console.WriteLine("\n                                Press the spacebar to shoot bullets"); ;
            Console.WriteLine("\n                              Shoot the aliens coming down the screen");
            Console.WriteLine("\n               Don't Let them touch the atmosphere (stars on the middle of the screen)");
            Console.WriteLine("\n                      If more than 3 aliens touch the atmosphere, earth is doomed");
            Console.WriteLine("\n                             Shoot all the aliens to save planet earth!");
            Console.WriteLine("\n                                Good luck out there Lieutenant {0}", soldierNameResponse);
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("\n\n                                  Press enter to initiate combat");
        }

        /*===================================================
                         MOVE FUNCTION
        ===================================================*/
        static ConsoleKey Move(int speedFalconSpeed)
        {

            shipOldX = shipCurrentX;
            shipOldY = shipCurrentY;

            switch (myKey)
            {
                case ConsoleKey.UpArrow:
                    shipCurrentY -= 1;
                    break;

                case ConsoleKey.DownArrow:
                    shipCurrentY += 1;
                    break;

                case ConsoleKey.RightArrow:
                    shipCurrentX += speedFalconSpeed;
                    break;

                case ConsoleKey.LeftArrow:
                    shipCurrentX -= speedFalconSpeed;
                    break;
            }

            return myKey;

        }

        /*===================================================
                          DRAW FUNCTION
        ===================================================*/
        static void Draw(string[] speedFalconDraw, string[] speedFalconErase, ConsoleKey myKeyDraw)
        {
            int j = 0;
            int i = 0;
            int shipAppearanceTop = shipCurrentY;
            int shipAppearanceBottom = shipCurrentY;


            for (i = 0; i < speedFalconDraw.Length; i++)
            {
                // ====== Erase Old SpeedFalcon Position ====== //

                ErasePlayer(myKeyDraw, speedFalconDraw, i, shipAppearanceTop, shipAppearanceBottom);

                for (j = 0; j < speedFalconDraw.Length; j++)
                {
                    // ====== Print New SpeedFalcon Position ====== //

                    Console.SetCursorPosition(shipCurrentX, shipAppearanceTop);
                    Console.Write(speedFalconDraw[i]);

                }
                shipAppearanceTop++;
            }
        }

        /*===================================================
                           ERASE FUNCTION
         ===================================================*/
        static void ErasePlayer(ConsoleKey eraseKey, string[] eraseAppearance, int eraseI, int eraseShipAppearanceTop,
                          int eraseShipAppearanceBottom)
        {
            if (eraseKey == ConsoleKey.RightArrow)
            {
                Console.SetCursorPosition(shipOldX, eraseShipAppearanceTop);
                Console.Write(eraseAppearance[eraseI].Replace(eraseAppearance[eraseI], "               "));
            }
            else if (eraseKey == ConsoleKey.LeftArrow)
            {
                Console.SetCursorPosition(shipOldX, eraseShipAppearanceTop);
                Console.Write(eraseAppearance[eraseI].Replace(eraseAppearance[eraseI], "               "));
            }
            else if (eraseKey == ConsoleKey.UpArrow)
            {
                Console.SetCursorPosition(shipOldX, eraseShipAppearanceTop + 1);
                Console.Write(eraseAppearance[eraseI].Replace(eraseAppearance[eraseI], "                "));
            }
            else if (eraseKey == ConsoleKey.DownArrow)
            {
                Console.SetCursorPosition(shipOldX, eraseShipAppearanceBottom - 1);
                Console.Write(eraseAppearance[eraseI].Replace(eraseAppearance[eraseI], "                "));
            }
            else
            {
                return;
            }
        }

        /*===================================================
                      HEADS UP DISPLAY FUNCTION
         ===================================================*/
        static void CharacterHeadsUpDisplay(string soldierNameHUD, string soldierLocationHUD, int shipHealthHUD)
        {
            string atmosphere = "*";
            for (i = 0; i < windowWidth; i++)
            {
                // ====== Position of HUD ====== //
     
                Console.SetCursorPosition(i, 35);
                Console.Write("=");
          
                Console.SetCursorPosition(i, 22);
                Console.Write(atmosphere);
            }
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            // ===== Solider Name ====== //

            Console.SetCursorPosition(0, 36);
            Console.Write("Soldier: {0}", soldierNameHUD);

            // ====== Soldier Location ====== //

            Console.SetCursorPosition(25, 36);
            Console.Write("Fighting out of: {0}", soldierLocationHUD);

            // ====== Bullets ====== //

            Console.SetCursorPosition(0, 38);
            Console.Write("Bullets: {0}", bulletNum);

            // ====== Kills ======= //

            Console.SetCursorPosition(35, 38);
            Console.Write("Score: {0}", score);

            // ====== Enemies Entered in Atmosphere ====== //

            Console.SetCursorPosition(65, 38);
            Console.Write("Enemies Invaded: {0}", enemiesInAtmosphere);
            //}                     
        }

        /*===================================================
                          BULLETS FUNCTION
         ===================================================*/

        static void BulletSpawn()
        {
            if (myKey == ConsoleKey.Spacebar)
            {
                bulletArrayX[bulletCounter] = shipCurrentX;
                bulletArrayY[bulletCounter] = shipCurrentY - 1;
                bulletNum--;
                bulletCounter++;
            }
        }

        static void BulletMove()
        {

            for (i = 0; i < bulletCounter; i++)
            {
                if (bulletArrayY[i] > 0)
                {
                    Console.SetCursorPosition(bulletArrayX[i], bulletArrayY[i]); // Erase Old Position
                    Console.Write("          ");

                    bulletArrayY[i]--;

                    Console.SetCursorPosition(bulletArrayX[i], bulletArrayY[i]); // Print New Position
                    Console.Write("   ‡     ‡");
                }
                else
                {
                    Console.SetCursorPosition(bulletArrayX[i], bulletArrayY[i]);
                    Console.Write("             ");
                }
                
            }

        }

        /*===================================================
                          LIMITS FUNCTION
         ===================================================*/
        static void Limits()
        {
            int widthEmptySpace = 13; // Since the ship model has empty space, we must rearrange the limits
            int HUDcoordinates = 31; // We don't want it to exit the boundaries of the HUD and atmosphere

            if (shipCurrentX > windowWidth - widthEmptySpace)
            {
                shipCurrentX = windowWidth - widthEmptySpace;
            }
            else if (shipCurrentX < 0)
            {
                shipCurrentX = 0;
            }
            else if (shipCurrentY <= atmosphereCoordinates)
            {
                shipCurrentY = atmosphereCoordinates + 1;
            }
            else if (shipCurrentY >= HUDcoordinates)
            {
                shipCurrentY = HUDcoordinates-1;
            }
        }

        /*===================================================
                          ENEMY1 FUNCTIONS
         ===================================================*/
        static void Enemy1Draw(string[] enemyDrawAppearance, int[] enemy1PositionXDraw, int[] enemy1PositionYDraw)
        {
            int j;


            for (j = 0; j < enemy1Counter; j++)
            {
                enemy1OldLocationX = enemy1PositionX[j];
                enemy1OldLocationY = enemy1PositionY[j];

                EraseEnemy1(enemyDrawAppearance, enemy1OldLocationX, enemy1OldLocationY);
                enemy1Top = enemy1PositionYDraw[j];
                for (i = 0; i < enemyDrawAppearance.Length; i++)
                {
                    enemy1Top++;
                    Console.SetCursorPosition(enemy1PositionXDraw[j], enemy1Top);
                    Console.Write(enemyDrawAppearance[i]);
                }
                if(enemy1PositionYDraw[j] == atmosphereCoordinates-4)
                {

                    EraseEntireEnemy1(enemyDrawAppearance, enemy1OldLocationX, enemy1OldLocationY);
                    continue;
                }
                enemy1PositionYDraw[j]++;
                
            }
        }

        static void Enemy1Spawn()
        {
            // ===== Random Positions ====== //

            int enemyXPosition = 0;
            int enemyYPosition;
            int enemy1Width = 8;
            Random random = new Random();
            enemyXPosition = random.Next(4, windowWidth - 8);
            enemyYPosition = random.Next(0, atmosphereCoordinates - 10);

            while(true)
            {
                // Prevent enemies from spawning at the same X coordinate (sorta works, not really)
                enemyXPosition = random.Next(4, windowWidth - 8);
                if(oldEnemyXPosition != enemyXPosition && (oldEnemyXPosition > enemyXPosition + enemy1Width || oldEnemyXPosition < enemyXPosition - enemy1Width))
                {
                    break;
                }
            }
            oldEnemyXPosition = enemyXPosition;
            enemy1PositionX[enemy1Counter] = enemyXPosition;
            enemy1PositionY[enemy1Counter] = 0;

            // ====== Enemy1 counter ====== //

            enemy1Counter++;
        }

        static void EraseEnemy1(string[] eraseEnemyAppearance, int eraseEnemy1X, int eraseEnemy1Y)
        {
            Console.SetCursorPosition(eraseEnemy1X, eraseEnemy1Y);
            Console.Write(eraseEnemyAppearance[0].Replace(eraseEnemyAppearance[0], "         "));
        }

        static void EraseEntireEnemy1(string[] enemy1Appearance, int enemy1PosX, int enemyPosY)
        {
            int enemyErase = 1;
            for(i = 0; i < enemy1Appearance.Length; i ++)
            {
                Console.SetCursorPosition(enemy1PosX, enemyPosY + enemyErase);
                Console.Write("           ");
                enemyErase++;               
            }
            enemiesInAtmosphere++;
        }

        /*===================================================
                          COLLISION FUNCTION
         ===================================================*/

        static void Collision(string[] enemy1AppearanceCollision)
        {
            int j = 0;
            for(i = 0; i < bulletCounter; i++)
            {
                for(j = 0; j < enemy1Counter; j++)
                {
                    if(bulletArrayX[i]+3 == enemy1PositionX[j] && bulletArrayY[i] == enemy1PositionY[j])
                    {
                        //EraseEntireEnemy1(enemy1AppearanceCollision, enemy1PositionX[j], enemy1PositionY[j]);
                        enemy1Movement[enemy1Counter] = true;
                        score++;
                    }
                }
            }           
            
        }

        /*===================================================
                          GAME OVER FUNCTION
         ===================================================*/
    }
}

