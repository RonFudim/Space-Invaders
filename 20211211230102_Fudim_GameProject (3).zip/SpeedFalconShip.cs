﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceInvadersGame
{
    class SpeedFalconShip
    {
        // ====== Attributes ====== //

        public string[] shipAppearance = new string[5] {"      ^   ",
                                                        "      o   ",
                                                        "   |  o  |      ",
                                                        "/\\ \\\\|o|// /\\",
                                                        "    </o\\>  "};
        public string[] shipErase = new string[5];
        public string shipName = "Speed Falcon";
        public string soldierName;
        public string soldierLocation;
        public int health = 150;
        public int speed = 4;
        public int energyAmount = 0;

        public SpeedFalconShip(ref string aSoldierName, ref string aSoldierLocation, ref int energy)
        {
            // ====== Speed Falcon Characteristics ====== //

            soldierName = aSoldierName;
            soldierLocation = aSoldierLocation;
            energyAmount = energy;
        }













    }
}